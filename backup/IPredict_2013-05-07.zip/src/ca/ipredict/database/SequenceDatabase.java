package ca.ipredict.database;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import ca.ipredict.predictor.TRuleGrowth_D.TRGItemset;
import ca.ipredict.predictor.TRuleGrowth_D.TRGSequence;


public class SequenceDatabase {

	private List<Sequence> sequences = new ArrayList<Sequence>();
	
	
	public SequenceDatabase() {
	}
	
	//Setter
	public void setSequences(List<Sequence> newSequences)	{
		this.sequences = new ArrayList<Sequence>(newSequences);
	}
	
	//Getter
	public List<Sequence> getSequences() {
		return sequences;
	}
	
	public int size() {
		return sequences.size();
	}
	
	public void clear() {
		sequences.clear();
	}
	
	
	public void loadFileBMSFormat(String filepath, int maxCount, int minSize) throws IOException {
		String thisLine;
		BufferedReader myInput = null;
		try {
			FileInputStream fin = new FileInputStream(new File(filepath));
			myInput = new BufferedReader(new InputStreamReader(fin));
			int realID = 0;
			int lastId = 0;
			
			int count = 0;
			Sequence sequence = null; //current sequence
			while ((thisLine = myInput.readLine()) != null  && count < maxCount) { //until end of file
				
				String[] split = thisLine.split(" ");
				int id = Integer.parseInt(split[0]);
				int val = Integer.parseInt(split[1]);
				
				if(lastId != id){ //if new sequence
					if(lastId!=0 && sequence.size() >= minSize){  //adding last sequence to sequences list
						sequences.add(sequence);
						realID++;
						count++;
					}
					sequence = new Sequence(id); //creating new sequence with current id
					lastId = id;
				}
				Item item = new Item(val); //adding current val to current sequence
				sequence.addItem(item);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (myInput != null) {
				myInput.close();
			}
		}
		
	}
	
	/**
	 * Load the sequences for a FIFA (World cup) log file
	 * see: http://ita.ee.lbl.gov/html/contrib/WorldCup.html
	 */
	public void loadFileFIFAFormat(String filepath, int maxCount, int minSize) throws IOException {

		try {
			FileInputStream fin = new FileInputStream(new File(filepath));
			DataInputStream myInput = new DataInputStream(fin);
			
			int id = 1;
			int count = 0;
			while(myInput.available() != 0 && count < maxCount) {
				//Create empty sequence
				Sequence seq = new Sequence(id);
				id++;
				
				//Getting the sequence length
				int length = myInput.readInt();
				
				
				//For each item , add it to the sequence
				for(int i = 0 ; i < length ; i++) {
					int value = myInput.readInt();
					seq.addItem(new Item(value));
				}
				
				if(seq.size() >= minSize) {
					//Adding the new sequence to the list of sequences
					sequences.add(seq);
					count++;
				}
			}
			
			fin.close();
			myInput.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	public void loadFileMsnbsFormat(String filepath, int maxCount, int minSize) throws IOException {
		String thisLine;
		BufferedReader myInput = null;
		try {
			FileInputStream fin = new FileInputStream(new File(filepath));
			myInput = new BufferedReader(new InputStreamReader(fin));
			int i = 0;
			while ((thisLine = myInput.readLine()) != null) {
				// ajoute une s�quence
				String[] split = thisLine.trim().split(" ");
				i++;
				if (maxCount == i) {
					break;
				}
				if(split.length >= minSize)	{ //min size restriction
					Sequence sequence = new Sequence(-1);
					for (String value : split) {
						Item item = new Item(Integer.valueOf(value)); //adding current val to current sequence
						sequence.addItem(item);
					}
					sequences.add(sequence);
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (myInput != null) {
				myInput.close();
			}
		}
		
	}
	
	
	public void loadFileKosarakFormat(String filepath, int maxCount, int minSize) throws IOException {
		String thisLine;
		BufferedReader myInput = null;
		try {
			FileInputStream fin = new FileInputStream(new File(filepath));
			myInput = new BufferedReader(new InputStreamReader(fin));
			int i = 0;
			while ((thisLine = myInput.readLine()) != null) {
				// ajoute une s�quence
				String[] split = thisLine.split(" ");
				i++;
				if (maxCount == i) {
					break;
				}
				if(split.length >= minSize)	{ //min size restriction
					Sequence sequence = new Sequence(-1);
					for (String value : split) {
						Item item = new Item(Integer.valueOf(value)); //adding current val to current sequence
						sequence.addItem(item);
					}
					sequences.add(sequence);
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (myInput != null) {
				myInput.close();
			}
		}
	}
	
	
	//Convert an integer from little endian to big endian
	public static int l2b(int i) {
		return ((i & 0xff) << 24) | ((i & 0xff00) << 8) | ((i & 0xff0000) >> 8) | ((i >> 24) & 0xff);
	}
	
	//Convert an unsigned int to a long (since unsigned int does not exist in java)
	public static long itol(int i) {
		return i & 0xffffffffl;
	}
}
