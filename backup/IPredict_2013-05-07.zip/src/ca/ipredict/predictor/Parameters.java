package ca.ipredict.predictor;

/**
 * Static set of parameters used globally
 * by the predictor and the controller
 * @author Ted Gueniche
 *
 */
public class Parameters {

	//BEST parameters:
	//[LossLessCompact]	
	
	//Preprocessing
	public static int sequenceMinSize = 1;
	
	//Sequence transformation
	public static int consequentSize = 2; //suffix-size
	public static int windowSize = 4; //prefix size
	
	//Rule evaluation
	public static int bestRuleCount = 1;
	
	//Rule generation
	public static double minsup = 0.0005;
	public static double minconf = 0.5;

	//Instantiation is forbidden
	private Parameters(){}
	
	public static String tostring() {
		String output = "Parameters";
		output += "sequenceMinSize: "+ sequenceMinSize;
		output += "consequentSize: "+ consequentSize;
		output += "windowSize: "+ windowSize;
		output += "bestRuleCount: "+ bestRuleCount;
		return output;
	}
}
