package ca.ipredict.predictor.losslesscompact;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import ca.ipredict.database.Item;
import ca.ipredict.database.Sequence;
import ca.ipredict.helpers.MemoryLogger;
import ca.ipredict.predictor.Predictor;

/**
 * Predictor based on a 3 main structures
 * a compact tree, an inverted index and a lookup table
 * @author Ted Gueniche
 *
 */
public class LossLessCompactPredictor implements Predictor {

	private CompactTree Root; //Compact tree
	private Map<Integer, CompactTree> LT; //Lookup Table
	private Map<Integer, BitSet> II;
	
	private long nodeNumber; //number of node in the Compact tree
	
	private List<Sequence> mTrainingSequences; //list of sequences to test
	
	/**
	 * Set the training set
	 */
	public void setTrainingSequences(List<Sequence> trainingSequences) {
		mTrainingSequences = trainingSequences;
	}
	
	/**
	 * Finds all branches that contains this sequences
	 * @param target sequence to find in the tree.
	 * @return List of sequence id ( can be transformed into leafs ) 
	 */
	private List<Integer> getMatchingSequences(Sequence target) {
		
		//find all sequences that have all the target's items
		//for each item in the target sequence
		List<Item> items = target.getItems();
		BitSet intersection = null; //get the bitset from the first item from target
		for(int i = 0 ; i < items.size(); i++) {
			BitSet bitset = II.get(items.get(i).val);
			if(bitset != null){
				if(intersection == null){
					intersection = (BitSet) bitset.clone();
				}else{
					intersection.and(bitset);
				}
			}
		}
		
		//if intersection is empty (no sequences contained all target's item
		if(intersection == null || intersection.cardinality() == 0)
			return new ArrayList<Integer>(); //no match
		
		List<Integer> lastIndexes = new ArrayList<Integer>(intersection.cardinality());
		
		//For each bit set to 1
		for (int i = intersection.nextSetBit(0); i >= 0; i = intersection.nextSetBit(i+1)) {
			lastIndexes.add(i);
		 }
		
		return lastIndexes;
	}
	
	/**
	 * Divides the target sequence into all possible sub sequence with a minimum size of minSize
	 * @param result The resulting list of sequence
	 * @param target The initial sequence to divide
	 * @param minSize The minimum size of a sub sequence
	 */
	private void RecursiveDivider(List<Sequence> result, Sequence target, int minSize) {
		int size = target.size();
		
		result.add(target); //adding the resulting sequence to the result list
		
		//if the target is small enough or already too small
		if(size <= minSize) {
			return;
		}

		//Hiding one item at the time from the target
		for(int toHide = 0; toHide < size; toHide++) {
			
			//Constructing a new sequence from the target without the "toHide" item
			Sequence newSequence = new Sequence(-1);
			for(int toUse = 0 ; toUse < size; toUse++) {
				
				if(toUse != toHide) {
					newSequence.addItem(target.get(toUse));
				}
			}
			
			RecursiveDivider(result, newSequence, minSize);
		}
	}


	
	/**
	 * Updates a CountTable based on a given sequence using the compactTree
	 * @param target Sequence to use
	 * @param weight Weight to add for each occurrence of an item in the CountTable
	 * @param CountTable The CountTable to update/fill
	 * @param hashSidVisited 
	 */

	private void UpdateCountTable(Sequence target, float weight, Map<Integer, Float> CountTable, HashSet<Integer> hashSidVisited) {

		List<Integer> indexes = getMatchingSequences(target); 
		
		//creating an HashMap of the target's item (for O(1) search time)
		HashSet<Integer> hashTarget = new HashSet<Integer>();
		for(Item it : target.getItems()) {
			hashTarget.add(it.val);
		}
		
		
		//For each branch 
		for(Integer index : indexes) {

			if(hashSidVisited.contains(index)){
				continue;    
			}   
			hashSidVisited.add(index); 
			
			//Getting the branch's leaf
			CompactTree curNode = LT.get(index);

			//Going up the branch until we find a item from the target
			while( (hashTarget.contains(curNode.Item.val) == false)) {
				
				//Getting the current count for this item if it exists or 0
				float oldValue = 0;
				if(CountTable.containsKey(curNode.Item.val)) {
					oldValue = CountTable.get(curNode.Item.val);
				}

				//Update the countable with the right weight and value
				CountTable.put(curNode.Item.val, oldValue + weight 
						/((float)indexes.size()) );  
				
				
				//Going up the tree
				curNode = curNode.Parent;
			}	

		}
	}
	
	/**
	 * Generate the highest rated sequence from a CountTable using the Lift or the Confidence
	 * @param CountTable The CountTable to use, it needs to be filled
	 * @param useLift Whether to use the Lift or the Confidence to calculate the score
	 * @return The highest rated sequence or an empty one if the CountTable is empty
	 */
	private Sequence getBestSequenceFromCountTable(Map<Integer, Float> CountTable, boolean useLift) {
		
		//Looking for the item with the highest count in the CountTable
		float maxValue = -1;
		Integer maxItem = -1;
		for(Map.Entry<Integer, Float> it : CountTable.entrySet()) {
			
			//the following measure of confidence and lift are "simplified" but are exactly the same as in the literature.
			//CONFIDENCE : |X -> Y|
			//LIFT: CONFIDENCE(X -> Y) / (|Y|)
			//Calculate score based on lift or confidence
//			float lift = it.getValue() / II.get(it.getKey()).cardinality();

			float confidence = it.getValue();
			float curScore = confidence;
			if(curScore > maxValue) {
				maxItem = it.getKey();
				maxValue = curScore;
			}
		}

		Sequence predicted = new Sequence(-1);
		
		//if there is a max item (there needs to be at least on item in the CountTable)
		if(maxItem != -1) {
			Item predictedItem = new Item(maxItem);
			predicted.addItem(predictedItem);
		}
			
		return predicted;
	}
	
	/**
	 * Predict the next element in the given sequence
	 * @param sequence to predict
	 */
	public Sequence Predict(Sequence target) {

		HashSet<Integer> hashSidVisited = new HashSet<Integer>();  // PFV
		
		//TODO: use those as global parameters
		//TODO: int minSize = (target.size() > 3) ? target.size() - 3 : 1;
		int minSize = 1;
		boolean useLift = false;
		
		//Dividing the target sequence into sub sequences
		List<Sequence> subSequences = new ArrayList<Sequence>();
		RecursiveDivider(subSequences, target, minSize);
		
//		//  ====== PFV -  COMMENTAIRE
		//  ICI, J'AI TENT� DE CHANGER L'ORDRE DE PARCOURT DES S�QUENCES
		// G�N�R�ES PAR LE RECURSIVE DIVIDER, ET CELA A UN IMPACT
		// CAR J'AI MODIFI� POUR QU'ON NE VISITE PAS LA M�ME SEQUENCE DEUX FOIS
		// POUR METTRE � JOUR LA COUNTTABLE.
		// J'AI TENT� DE TRIER PAR ORDRE CROISSANT ET D�CROISSANT DE TAILLE
		// ET CELA DONNE DE MOINS BON R�SULTATS QUE L'ORDRE PAR D�FAUT DU RECURSIVE DIVIDER.
		// DONC, JE LAISSE LE CODE QUE J'AI AJOUT� EN COMMENTAIRE
//		Collections.sort(subSequences, new Comparator<Sequence>(){
//			public int compare(Sequence arg0, Sequence arg1) {
//				return arg1.size() - arg0.size();
//			}});
		
		//For each subsequence, updating the CountTable
		Map<Integer, Float> CountTable = new HashMap<Integer, Float>();
		for(Sequence sequence : subSequences) {
			
			float weight = 1f; 
			//float weight = 1d  / target.size(); // PFV: augmente un peu la pr�cision
			//float weight = (float)sequence.size() / target.size(); //original
			UpdateCountTable(sequence, weight, CountTable, hashSidVisited);
		}

		//Getting the best sequence out of the CountTable
		return getBestSequenceFromCountTable(CountTable, useLift);
	}
	
	@Override
	public String getTAG() {
		return "LLCT";
	}
	
	
	/**
	 * Trains this predictor with training data, use "setTrainingSequences()" first
	 * @return true on success
	 */
	public Boolean Preload() {
		
		nodeNumber = 0;
		int seqId = 0; //current sequence from database
		Root = new CompactTree();
		LT = new HashMap<Integer, CompactTree>();
		II = new HashMap<Integer, BitSet>();
		
		//Logging memory usage
		MemoryLogger.addUpdate();
			
		//For each line (sequence) in file
		for(Sequence curSeq : mTrainingSequences) {
		
			CompactTree curNode = Root;
			
			//for each item in this sequence
			for(Item it : curSeq.getItems()) {
				
				//if item is not in Inverted Index then we add it
				if(II.containsKey(it.val) == false) {
					BitSet tmpBitset = new BitSet();
					II.put(it.val, tmpBitset);
				}
				//updating Inverted Index with seqId for this Item
				
				II.get(it.val).set(seqId);
				
				//if item is not in compact tree then we add it
				if(curNode.hasChild(it) == false) {
					curNode.addChild(it);
					nodeNumber++;
				}
				curNode = curNode.getChild(it);
			}
			
			LT.put(seqId, curNode); //adding <sequence id, last node in sequence>
			seqId++; //increment sequence id number
		}

		
		
		/**
		 * OPTIMIZATION:
		 * Removes all the unique items with a really low support from the inverted index.
		 * Should be tested some more, appears to boost the coverage with no significant effect on the precision
		 */
		/*
		int minSup = 0; //should be relative instead of absolute // for bms try: 50
		Iterator it = II.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry<Integer, BitSet> pairs = (Map.Entry)it.next();
	        
	        if(pairs.getValue().cardinality() < minSup) {
	        	it.remove();
	        }
	    }
	    */
	    /*****************END OF OPTIMIZATION***********************/
		
		
		//Logging memory usage
		MemoryLogger.addUpdate();
		
		return true;
	}
	
	public long size() {
		return nodeNumber;
	}
	
	/*
	//DEBUG
	public static void main(String[] args) {
		LossLessCompactPredictor predictor = new LossLessCompactPredictor();
		
		
		Sequence seq = new Sequence(-1);
		seq.addItem(new Item(1));
		seq.addItem(new Item(2));
		seq.addItem(new Item(3));
		seq.addItem(new Item(4));
		
		List<Sequence> result = new ArrayList<Sequence>();

		int minSize = 2;
		
		
		predictor.RecursiveDivider(result, seq, minSize);
		
		for(Sequence sequence : result) {
			System.out.println(sequence.toString());
		}
		
	}
	*/
}
