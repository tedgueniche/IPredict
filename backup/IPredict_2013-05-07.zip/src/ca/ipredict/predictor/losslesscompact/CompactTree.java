package ca.ipredict.predictor.losslesscompact;
import java.util.ArrayList;
import java.util.List;

import ca.ipredict.database.Item;


public class CompactTree {

	public int Support; //support count
	public Item Item; //actual item
	public CompactTree Parent; //parent's node
	
	private List<CompactTree> Children; //children list
	
	
	public CompactTree(Item itemValue) {
		Support = 0; //default support
		Item = itemValue;
		Children = new ArrayList<CompactTree>();
		Parent = null;
	}
	
	public CompactTree() {
		Support = 0; //default support
		Item = new Item();
		Children = new ArrayList<CompactTree>();
		Parent = null;
	}
	
	public void addChild(Item child) {
		CompactTree newChild = new CompactTree(child);
		newChild.Parent = this;
		Children.add(newChild);
	}
	
	public Boolean hasChild(Item target) {
		
		for(CompactTree child : Children) {
			if(child.Item.val.equals(target.val)) {
				return true;
			}
		}
		
		return false;
	}
	
	public CompactTree getChild(Item target) {

		for(CompactTree child : Children) {
			if(child.Item.val.equals(target.val))
				return child;
		}
		
		return null;
	}

}
